AGRI-DECISION - SCENARIO 3 CODEATHON APP

1. Install Python 3.10+
2. Open Command Prompt in this folder
3. Run: pip install -r requirements.txt
4. Run: python app.py
5. Open: http://127.0.0.1:5000

The app includes farmer inputs, simple price forecasting, Best/Base/Worst scenarios, risk scoring, and a recommendation.
This is a prototype. For production, connect verified local market/mandi and weather data.
