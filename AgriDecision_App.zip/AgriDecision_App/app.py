from flask import Flask, render_template, request
from statistics import mean
app=Flask(__name__)

def analyze(f):
    crop=f['crop']; qty=float(f['quantity']); loc=f['location']; cur=float(f['price']); transport=float(f['transport']); cost=float(f['cost']); loan=float(f['loan']); weather=f['weather']; demand=f['demand']
    hist=[float(x.strip()) for x in f['history'].split(',') if x.strip()]
    if len(hist)<2: hist=[cur*.9,cur*.95,cur]
    avg=mean(hist); trend=hist[-1]-hist[0]
    forecast=[max(0,avg+trend*(d/max(1,len(hist)-1))) for d in range(1,11)]
    f3,f7=forecast[2],forecast[6]
    df={'Low':.9,'Medium':1,'High':1.1}[demand]; wf={'Low':1,'Medium':.9,'High':.75}[weather]
    total=cost+qty*transport
    data=[('Best Case',max(cur,f7)*1.15*df,qty*1.05,'best','Favourable weather and strong demand'),('Base Case',f3*df,qty*wf,'base','Normal conditions'),('Worst Case',cur*.75,qty*.70,'worst','Weather shock and price decline')]
    scenarios=[]
    for n,p,q,c,d in data: scenarios.append({'name':n,'price':p,'quantity':q,'class':c,'description':d,'revenue':p*q,'profit':p*q-total})
    wr={'Low':10,'Medium':30,'High':60}[weather]; dr={'Low':25,'Medium':15,'High':5}[demand]
    base_profit=scenarios[1]['profit']; lr=0 if loan==0 else (5 if base_profit>=loan else 25 if base_profit>=loan*.5 else 50)
    risk=min(100,wr+dr+lr+(10 if transport>5 else 0)); level='LOW' if risk<35 else 'MEDIUM' if risk<65 else 'HIGH'
    scores=[scenarios[0]['profit']/1000-4, scenarios[1]['profit']/1000-.2*risk, scenarios[2]['profit']/1000-16]
    selected=scenarios[scores.index(max(scores))]
    rec='WAIT 7 DAYS' if f7>cur*1.10 and risk<60 else 'WAIT 3 DAYS' if f3>cur*1.05 and risk<70 else 'SELL NOW'
    reasons=[('Price trend is positive.' if f3>cur else 'Short-term price trend is weak.'),('7-day forecast shows further upside.' if f7>f3 else 'Longer waiting offers limited price benefit.'),('Weather risk is manageable.' if weather!='High' else 'Weather risk is high.'),('Market demand is strong.' if demand=='High' else 'Market demand is stable.' if demand=='Medium' else 'Market demand is weak.'),('Loan pressure is manageable.' if base_profit>=loan else 'Loan repayment pressure needs attention.')]
    return locals()

@app.route('/')
def home(): return render_template('index.html')
@app.route('/analyze',methods=['POST'])
def result(): return render_template('result.html',r=analyze(request.form))
if __name__=='__main__': app.run(debug=True)
